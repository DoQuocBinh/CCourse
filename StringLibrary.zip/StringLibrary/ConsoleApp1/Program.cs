﻿using System;
using UtilityLibraries;
using Newtonsoft.Json;
using ExcerciseLib;

namespace ConsoleApp1
{
    public class Account
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime DOB { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //string msg = "Hello you";
            //bool r = msg.StartsWithUpper();
            //Console.WriteLine(r);
            //Account account = new Account
            //{
            //    Name = "John Doe",
            //    Email = "john@nuget.org",
            //    DOB = new DateTime(1980, 2, 20, 0, 0, 0, 
            //        DateTimeKind.Utc),
            //};

            //string json = JsonConvert.
            //    SerializeObject(account, Formatting.Indented);
            //Console.WriteLine(json);
            var str1 = "abcXYZ";
            Console.WriteLine(str1.StartWithLowerCase());
            Console.WriteLine(str1.StartWithDigit());

            Console.ReadLine();
        }
    }
}
