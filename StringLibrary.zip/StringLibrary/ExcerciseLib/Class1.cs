﻿using System;

namespace ExcerciseLib
{
    public static class ExcerciseString
    {
        public static bool StartWithLowerCase(this string str)
        {
            if (String.IsNullOrWhiteSpace(str))
                return false;
            Char ch = str[0];
            return Char.IsLower(ch);
        }
        public static bool StartWithDigit(this string str)
        {
            if (String.IsNullOrWhiteSpace(str))
                return false;
            Char ch = str[0];
            return char.IsDigit(ch);
        }
    }
}
